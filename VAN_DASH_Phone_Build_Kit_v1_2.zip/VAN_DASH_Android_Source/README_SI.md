# VAN DASH – Android Source Project (v1.2)

මෙය Android phone එකකින් code එක බලන්න/සංස්කරණය කරන්නත්, පසුව Android Studio හෝ ගැළපෙන Android IDE එකකින් build කරන්නත් සකස් කළ මුල් project එකකි.

## දැනට ඇතුළත් දේ
- GPS speed (km/h)
- GPS location status සහ coordinates
- Trip distance (app එක විවෘතව ඇති කාලය තුළ)
- Open-Meteo මගින් current temperature සහ weather description
- වෙනම OpenStreetMap screen එක
- English dark dashboard interface

## Build කිරීම
1. Project ZIP එක extract කරන්න.
2. Android Studio එකෙන් `VAN_DASH_Android_Source` folder එක open කරන්න.
3. Gradle sync ඉවර වනතුරු රැඳී සිටින්න.
4. Android device එක connect කර Run කරන්න.
5. Location permission ලබා දෙන්න.

## වැදගත් සීමා
- මෙය source-code starter project එකක් මිස දැනටමත් build කර පරීක්ෂා කළ APK එකක් නොවේ.
- මෙහි APK එක compile කර නැත; build කිරීම සඳහා Android build environment එකක් අවශ්‍යයි.
- GPS speed එක reception සහ phone placement අනුව වෙනස් විය හැකියි. වාහනයේ speedometer එකට ආදේශකයක් නොවේ.
- Weather සඳහා internet අවශ්‍යයි. Open-Meteo API භාවිත කරයි.
- Media Player එකට phone එකේ audio library permission අවශ්‍යයි; දැනට online streaming නොමැත. Bluetooth sound routing Android system එකෙන් සිදුවේ.
- Bluetooth headset / vehicle media buttons ක්‍රියා කිරීම ඒවා Android media-key events ලබාදෙනවාද යන්න මත රඳා පවතී. Steering-wheel controls සියලුම වාහනවල සහතික කළ නොහැක.
- MediaSession controls Media Player screen එක විවෘතව තිබෙන විට සක්‍රිය වේ. App එක සම්පූර්ණයෙන් වසා දැමූ පසු background playback සහ notification controls සහතික නොවේ.
- Map එක OpenStreetMap website එක WebView තුළ පෙන්වයි; turn-by-turn voice navigation තවම නැත.
- Trip distance දැනට app එක ක්‍රියාත්මකව තිබෙන කාලයට පමණි; save/resume කිරීම තවම එකතු කර නැත.
- Driving අතරතුර phone එක අතින් භාවිත නොකරන්න. Map එක passenger කෙනෙකුට හෝ නවතා ඇති විට භාවිත කරන්න.

## Package
`com.sacymultishop.vandash`

## Version 1.2 update
- Bluetooth audio output routing through Android
- MediaSession transport controls for compatible Bluetooth / headset media buttons
- Correct Previous and Next track controls

## Remaining optional enhancements
1. Persistent trip history
2. Compass sensor + heading
3. Full turn-by-turn navigation and destination search
4. Landscape dashboard / night mode
5. Background media playback service and signed release APK
