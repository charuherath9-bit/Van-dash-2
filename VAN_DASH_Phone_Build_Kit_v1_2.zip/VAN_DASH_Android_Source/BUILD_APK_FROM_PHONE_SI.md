# VAN DASH APK එක phone එකෙන් build කිරීම

මෙම project එකේ `.github/workflows/build-apk.yml` cloud build workflow එකක් ඇත.
Laptop එකක් අවශ්‍ය නැහැ. GitHub account එකක් සහ browser එකක් අවශ්‍යයි.

1. GitHub වෙබ් අඩවියට ගොස් account එකක් තිබේ නම් sign in කරන්න.
2. New repository එකක් සාදන්න. උදාහරණ නම: `VAN-DASH`.
3. මේ ZIP එක extract කරලා ඇතුළත ඇති `VAN_DASH_Android_Source` folder එකේ අන්තර්ගත සියල්ල repository එකට upload කරන්න. `.github` folder එකත් upload විය යුතුයි.
4. Repository එකේ **Actions** tab එකට යන්න.
5. **Build VAN DASH APK** workflow එක තෝරා **Run workflow** ඔබන්න.
6. Build එක සාර්ථක වූ පසු workflow run එකේ **Artifacts** යටතේ `VAN-DASH-debug-APK` download කරන්න.
7. ZIP එක extract කර `app-debug.apk` file එක Android phone එකෙන් open කර install කරන්න. Android විසින් ඉල්ලුවොත් browser/files app එකට APK install permission දෙන්න.

සටහන:
- මෙය debug APK එකකි; Play Store release signing කර නැත.
- GitHub Actions build එක සාර්ථකදැයි පළමුව පරීක්ෂා කළ යුතුය.
- APK එක install කිරීමට පෙර build එකේ warnings/errors තිබේදැයි බලන්න.
- රිය පැදවීමේදී phone එක අතින් භාවිතා නොකරන්න.
