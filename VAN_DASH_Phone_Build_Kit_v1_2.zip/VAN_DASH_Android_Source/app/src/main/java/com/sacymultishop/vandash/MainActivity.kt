package com.sacymultishop.vandash

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.net.Uri
import android.provider.MediaStore
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val Bg = Color(0xFF080D17)
private val Panel = Color(0xFF131D2D)
private val Cyan = Color(0xFF39D7FF)
private val Muted = Color(0xFF9BAABD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VanDashApp() }
    }
}

@Composable
fun VanDashApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("dashboard") }
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED
        )
    }
    var speed by remember { mutableIntStateOf(0) }
    var latitude by remember { mutableStateOf<Double?>(null) }
    var longitude by remember { mutableStateOf<Double?>(null) }
    var distanceKm by remember { mutableDoubleStateOf(0.0) }
    var weather by remember { mutableStateOf("Waiting for GPS…") }
    var temperature by remember { mutableStateOf("--°C") }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermission = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) {
            permissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    DisposableEffect(hasPermission) {
        if (!hasPermission) return@DisposableEffect onDispose { }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var previous: Location? = null
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                speed = if (location.hasSpeed()) (location.speed * 3.6f).roundToInt() else 0
                latitude = location.latitude
                longitude = location.longitude
                previous?.let {
                    val meters = it.distanceTo(location)
                    if (meters in 1f..500f) distanceKm += meters / 1000.0
                }
                previous = Location(location)
            }
        }
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener)
            }
        } catch (_: SecurityException) { }
        onDispose { try { lm.removeUpdates(listener) } catch (_: Exception) { } }
    }

    LaunchedEffect(latitude, longitude) {
        val lat = latitude
        val lon = longitude
        if (lat != null && lon != null) {
            try {
                val result = withContext(Dispatchers.IO) {
                    val body = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto")
                        .readText()
                    JSONObject(body).getJSONObject("current")
                }
                temperature = "${result.getDouble("temperature_2m").roundToInt()}°C"
                weather = weatherName(result.getInt("weather_code"))
            } catch (_: Exception) {
                weather = "Weather unavailable"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (page) {
                "map" -> MapPage(latitude, longitude) { page = "dashboard" }
                "media" -> MediaPage { page = "dashboard" }
                else -> Dashboard(
                    speed, temperature, weather, distanceKm, latitude, longitude,
                    hasPermission,
                    onMap = { page = "map" },
                    onMedia = { page = "media" },
                    onPermission = {
                        permissionLauncher.launch(arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ))
                    }
                )
            }
        }
    }
}

@Composable
private fun Dashboard(
    speed: Int, temperature: String, weather: String, distanceKm: Double,
    latitude: Double?, longitude: Double?, hasPermission: Boolean,
    onMap: () -> Unit, onMedia: () -> Unit, onPermission: () -> Unit
) {
    var time by remember { mutableStateOf("--:--") }
    LaunchedEffect(Unit) {
        while (true) {
            time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(1000)
        }
    }
    Column(
        Modifier.fillMaxSize().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("VAN DASH", color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("SMART DRIVING DISPLAY", color = Muted, fontSize = 10.sp)
            }
            Text(time, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(22.dp))
        Box(
            Modifier.size(250.dp).background(Panel, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("GPS SPEED", color = Muted, fontSize = 13.sp)
                Text("$speed", color = Color.White, fontSize = 76.sp, fontWeight = FontWeight.Black)
                Text("KM/H", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("TEMPERATURE", temperature, Modifier.weight(1f))
            InfoCard("WEATHER", weather, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("TRIP DISTANCE", String.format(Locale.US, "%.2f km", distanceKm), Modifier.weight(1f))
            InfoCard("GPS STATUS", if (hasPermission && latitude != null) "Connected" else "Waiting", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        if (!hasPermission) {
            Text("Location permission is needed for GPS speed and local weather.",
                color = Muted, fontSize = 12.sp)
            TextButton(onClick = onPermission) { Text("Enable location") }
        } else if (latitude != null && longitude != null) {
            Text("GPS: %.5f, %.5f".format(Locale.US, latitude, longitude),
                color = Muted, fontSize = 10.sp)
        } else {
            Text("Waiting for GPS signal…", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onMap,
                modifier = Modifier.weight(1f).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Map, contentDescription = null, tint = Bg)
                Spacer(Modifier.width(7.dp))
                Text("MAP", color = Bg, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = onMedia,
                modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("MEDIA", fontWeight = FontWeight.Bold)
            }
        }
        Text("Use only when safely parked or with a passenger.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun InfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            maxLines = 2)
    }
}

@Composable
private fun MapPage(latitude: Double?, longitude: Double?, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text("NAVIGATION MAP", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        if (latitude == null || longitude == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Waiting for GPS location…", color = Color.White)
            }
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        webViewClient = WebViewClient()
                        loadUrl("https://www.openstreetmap.org/?mlat=$latitude&mlon=$longitude#map=16/$latitude/$longitude")
                    }
                },
                update = { view ->
                    // The initial map remains open; the marker is centred on the latest known GPS position.
                }
            )
        }
    }
}


private data class AudioTrack(val id: Long, val title: String, val artist: String)

@Composable
private fun MediaPage(onBack: () -> Unit) {
    val context = LocalContext.current
    var tracks by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
    var selectedIndex by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Allow audio access to browse music on this phone.") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    val mediaSession = remember(context) { MediaSessionCompat(context, "VAN_DASH_MEDIA") }

    fun publishPlaybackState(isPlaying: Boolean) {
        val state = if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                    PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                    PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_STOP
                )
                .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, if (isPlaying) 1f else 0f)
                .build()
        )
    }

    fun publishTrack(track: AudioTrack) {
        mediaSession.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, track.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, track.artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "VAN DASH")
                .build()
        )
    }

    val audioPermission = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun loadTracks() {
        val found = mutableListOf<AudioTrack>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        try {
            context.contentResolver.query(collection, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (cursor.moveToNext()) {
                    found.add(AudioTrack(
                        cursor.getLong(idCol),
                        cursor.getString(titleCol) ?: "Unknown track",
                        cursor.getString(artistCol) ?: "Unknown artist"
                    ))
                }
            }
            tracks = found
            status = if (found.isEmpty()) "No music files found on this phone." else "Choose a track to play."
        } catch (_: SecurityException) {
            status = "Audio permission is required."
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) loadTracks() else status = "Permission denied. Allow audio access in Settings."
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        } else {
            permissionLauncher.launch(audioPermission)
        }
    }

    fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        try {
            player?.release()
            val track = tracks[index]
            val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, track.id.toString())
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(context, uri)
                setOnCompletionListener {
                    if (index + 1 < tracks.size) playTrack(index + 1)
                    else {
                        playing = false
                        publishPlaybackState(false)
                    }
                }
                prepare()
                start()
            }
            selectedIndex = index
            playing = true
            publishTrack(track)
            publishPlaybackState(true)
            status = "Now playing · Bluetooth audio follows your phone's output route"
        } catch (_: Exception) {
            playing = false
            status = "Unable to play this audio file."
        }
    }

    DisposableEffect(mediaSession) {
        mediaSession.setFlags(
            MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
        )
        mediaSession.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() {
                val current = player
                if (current != null) {
                    current.start()
                    playing = true
                    publishPlaybackState(true)
                } else if (tracks.isNotEmpty()) {
                    playTrack(if (selectedIndex >= 0) selectedIndex else 0)
                }
            }
            override fun onPause() {
                player?.pause()
                playing = false
                publishPlaybackState(false)
            }
            override fun onSkipToNext() {
                if (selectedIndex + 1 < tracks.size) playTrack(selectedIndex + 1)
            }
            override fun onSkipToPrevious() {
                if (selectedIndex > 0) playTrack(selectedIndex - 1)
            }
            override fun onStop() {
                player?.pause()
                playing = false
                publishPlaybackState(false)
            }
        })
        mediaSession.isActive = true
        onDispose {
            mediaSession.isActive = false
            mediaSession.release()
            player?.release()
            player = null
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Column {
                Text("MEDIA PLAYER", color = Cyan, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("PHONE MUSIC LIBRARY", color = Muted, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = Cyan,
                modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(8.dp))
            Text(
                if (selectedIndex in tracks.indices) tracks[selectedIndex].title else "Select a track",
                color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                if (selectedIndex in tracks.indices) tracks[selectedIndex].artist else status,
                color = Muted, fontSize = 12.sp, maxLines = 2
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (selectedIndex > 0) playTrack(selectedIndex - 1)
                }) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous track",
                        tint = Muted, modifier = Modifier.size(30.dp))
                }
                FilledIconButton(
                    onClick = {
                        val current = player
                        if (current != null && playing) {
                            current.pause()
                            playing = false
                            publishPlaybackState(false)
                        } else if (current != null) {
                            current.start()
                            playing = true
                            publishPlaybackState(true)
                        } else if (tracks.isNotEmpty()) {
                            playTrack(if (selectedIndex >= 0) selectedIndex else 0)
                        }
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Cyan)
                ) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playing) "Pause" else "Play",
                        tint = Bg
                    )
                }
                IconButton(onClick = {
                    if (selectedIndex + 1 < tracks.size) playTrack(selectedIndex + 1)
                }) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next track",
                        tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("MUSIC LIBRARY  •  ${tracks.size} TRACKS", color = Muted,
            fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(status, color = Muted)
                    TextButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, audioPermission) ==
                            PackageManager.PERMISSION_GRANTED) loadTracks()
                        else permissionLauncher.launch(audioPermission)
                    }) { Text("Grant access / Refresh") }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(tracks) { index, track ->
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (index == selectedIndex) Color(0xFF20374A) else Panel,
                                RoundedCornerShape(12.dp))
                            .clickable { playTrack(index) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold,
                                maxLines = 1)
                            Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1)
                        }
                        if (index == selectedIndex && playing) {
                            Text("PLAYING", color = Cyan, fontSize = 9.sp,
                                fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        Text("Bluetooth audio uses your phone's connected audio output. Compatible headset / vehicle media buttons may control playback.",
            color = Muted, fontSize = 10.sp)
        Text("Use controls only when parked or through a passenger / hands-free controls.",
            color = Muted, fontSize = 10.sp)
    }
}

private fun weatherName(code: Int): String = when (code) {
    0 -> "Clear"
    1, 2 -> "Partly cloudy"
    3 -> "Cloudy"
    45, 48 -> "Fog"
    in 51..67 -> "Drizzle / Rain"
    in 71..77 -> "Snow"
    in 80..82 -> "Rain showers"
    in 95..99 -> "Thunderstorm"
    else -> "Current weather"
}
